export const Token = {
  SUI: 'SUI',
};
