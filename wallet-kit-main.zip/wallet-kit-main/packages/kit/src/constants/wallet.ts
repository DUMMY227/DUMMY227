export const WalletNames = {
  SUI_WALLET: 'Sui Wallet',
  SUIET_WALLET: 'Suiet',
};
