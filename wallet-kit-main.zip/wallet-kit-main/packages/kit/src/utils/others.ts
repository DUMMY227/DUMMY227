export function swrLoading(data: any, error: any) {
  return !error && !data;
}
