export enum AccountStatus {
  disconnected = 'disconnected',
  connected = 'connected',
  connecting = 'connecting',
}
